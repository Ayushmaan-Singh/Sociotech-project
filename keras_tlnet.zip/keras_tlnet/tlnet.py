from inspect import Arguments
import keras
from keras import activations
from keras.backend import backend
from keras.backend.cntk_backend import _pad, concatenate, conv1d, conv2d, tile
from keras.layers import Input, Add, Dense, Activation, Flatten, conv2d, MaxPooling2D, Zeropad2D,GlobalAveragePooling2D, TimeDistributed,Dropout,Concatenate
from keras.layers.core import Lambda
from keras.layers.normalization import BatchNormalization
from keras.models import Sequential,Model
from keras import backend as K
import numpy as np
import argparse
from threading import Thread

def conv2d_block(x,numfilt,filtsz,strides=1,pad='same',act=True,name=None):
    x=conv2d(numfilt,filtsz,strides,padding=pad,data_format="channel_last",use_bias=False,name=name+"conv2d")(x)
    x=BatchNormalization(axis=3,scale=False,name=name+"conv2d"+'bn')(x)
    if act:
        x=Activation("relu",name=name+"conv2d"+'act')(x)
    return x
    

def Model_1(x,scale,name=None):
    pad="same"
    branch0=conv2d_block(x,32,1,1,pad,True,name=name+"b0")
    branch1=conv2d_block(x,32,1,1,pad,True,name=name+"b1_1")
    branch1=conv2d_block(branch1,32,3,1,pad,True,name=name+"b1_2")
    branch2=conv2d_block(x,32,1,1,pad,True,name=name+"b2_1")
    branch2=conv2d_block(branch2,48,3,1,pad,True,name=name+"b2_2")
    branch2=conv2d_block(branch2,64,3,1,pad,True,name=name+"b2_3")
    branches=[branch0,branch1,branch2]
    concat=Concatenate(axis=3,name=name+"concat")(branches)
    flt1=conv2d_block(concat,384,1,1,pad,True,name=name+'filt1')
    final=Lambda(lambda inputs, scale:input[0]*input[1]*scale,output_shape=backend.int_shape(x)[1:],Arguments={'scale':scale},name=name+"act_scaling")([x,flt1])
    return final
def Model_2(x,scale,name=None):
    pad='same'
    branch0=conv2d_block(x,192,1,1,pad,True,name=name+'b0')
    branch1=conv2d_block(x,128,1,1,pad,True,name=name+'b1_1')
    branch1=conv2d_block(branch1,160,[1,7],1,pad,True,name=name+'b1_2')
    branch1=conv2d_block(branch1,192,[7,1],1,pad,True,name=name+'b1_3')
    branches=[branch0,branch1]
    concat=Concatenate(axis=3,name=name+'concat')(branches)
    flt1=conv2d_block(concat,1152,1,1,pad,True,name=name+'flt1')
    final=Lambda(lambda inputs,scale:input[0]*input[1]*scale,output_shape=backend.int_shape(x)[1:],Arguments={'sacle':scale},name=name+'act_scaling')([x,flt1])
    return final

def Model_3(x,scale,name=None):
    pad='same'
    branch0=conv2d_block(x,192,1,1,pad,True,name=name+"b0")
    branch1=conv2d_block(x,191,1,1,pad,True,name=name+"b1_1")
    branch1=conv2d_block(branch1,224,[1,3],1,pad,True,name=name+"b1_2")
    branch1=conv2d_block(branch1,256,[3,1],1,pad,True,name=name+"b1_3")
    branches=[branch0,branch1]
    concat=Concatenate(axis=3,name=name+"concat")
    filt1=conv2d_block(concat,2048,1,1,pad,True,name=name+'flt1')
    final=Lambda(lambda input,scale:input[0]*input[1]*scale,output_shape=backend.int_shape(x)[1:],Arguments={"scale":scale},name=name+"act_scaling")([x,filt1])
    return final

def stem():
    image_input=Input(shape=(256,256,3))
    x=conv2d_block(image_input,32,2,1,'valid',True,name='conv1')
    x=conv2d_block(x,32,3,1,'valid',True,name='conv2')
    x=conv2d_block(x,64,3,1,'valid',True,name='conv3')

    x_11=MaxPooling2D(3,strides=1,padding='valid',name='stem_br11_maxpool1')(x)
    x_12=conv2d_block(x,64,3,1,'valid',True,name='stem_br12')

    x=Concatenate(axis=3,name='stem_concat1')([x_11,x_12])

    x_21=conv2d_block(x,64,1,1,'same',True,name="stem_br211")
    x_21=conv2d_block(x_21,64,[1,7],1,"same",True,name="stem_br212")
    x_21=conv2d_block(x_21,[7,1],1,"same",True,name="stem_br213")
    x_21=conv2d_block(x_21,96,3,1,"valid",True,name="stem_br214")

    x_22=conv2d_block(x,64,1,1,'same',True,name="stem_br221")
    x_22=conv2d_block(x_22,96,3,1,'valid',True,name="stem_br222")
    
    x=Concatenate(axis=3,name="stem_concat2")([x_21,x_22])

    x_31=conv2d_block(x,192,3,1,'valid',True,name="stem_br311")
    x_32=MaxPooling2D(3,strides=1,padding='valid',name="stem_br32_maxpool2")(x)

    x=Concatenate(axis=3,name="stem_concat3")([x_31,x_32])

def rpn(base_layers,num_anchors):

    x = conv2d(512, (3, 3), padding='same', activation='relu', kernel_initializer='normal', name='rpn_conv1')(base_layers)

    x_class = conv2d(num_anchors, (1, 1), activation='sigmoid', kernel_initializer='uniform', name='rpn_out_class')(x)
    x_regr = conv2d(num_anchors * 4, (1, 1), activation='linear', kernel_initializer='zero', name='rpn_out_regress')(x)

    return [x_class, x_regr, base_layers]

def conv_block_td(input_tensor, kernel_size, filters, stage, block, input_shape, strides=(2, 2), trainable=True):
    # conv block time distributed
    nb_filter1, nb_filter2, nb_filter3 = filters
    if K.common.image_dim_ordering() == 'tf':
        bn_axis = 3
    else:
        bn_axis = 1

    conv_name_base = 'res' + str(stage) + block + '_branch'
    bn_name_base = 'bn' + str(stage) + block + '_branch'

    x = TimeDistributed(conv2d(nb_filter1, (1, 1), strides=strides, trainable=trainable, kernel_initializer='normal'), input_shape=input_shape, name=conv_name_base + '2a')(input_tensor)
    x = TimeDistributed(FixedBatchNormalization(axis=bn_axis), name=bn_name_base + '2a')(x)
    x = Activation('relu')(x)

    x = TimeDistributed(conv2d(nb_filter2, (kernel_size, kernel_size), padding='same', trainable=trainable, kernel_initializer='normal'), name=conv_name_base + '2b')(x)
    x = TimeDistributed(FixedBatchNormalization(axis=bn_axis), name=bn_name_base + '2b')(x)
    x = Activation('relu')(x)

    x = TimeDistributed(conv2d(nb_filter3, (1, 1), kernel_initializer='normal'), name=conv_name_base + '2c', trainable=trainable)(x)
    x = TimeDistributed(FixedBatchNormalization(axis=bn_axis), name=bn_name_base + '2c')(x)

    shortcut = TimeDistributed(conv2d(nb_filter3, (1, 1), strides=strides, trainable=trainable, kernel_initializer='normal'), name=conv_name_base + '1')(input_tensor)
    shortcut = TimeDistributed(FixedBatchNormalization(axis=bn_axis), name=bn_name_base + '1')(shortcut)

    x = Add()([x, shortcut])
    x = Activation('relu')(x)
    return x

def nn_base(input_tensor=None, trainable=False):
    # Determine proper input shape
    if K.common.image_dim_ordering() == 'th':
        input_shape = (3, None, None)
    else:
        input_shape = (None, None, 3)

    if input_tensor is None:
        img_input = Input(shape=input_shape)
    else:
        if not K.is_keras_tensor(input_tensor):
            img_input = Input(tensor=input_tensor, shape=input_shape)
        else:
            img_input = input_tensor

    if K.common.image_dim_ordering() == 'tf':
        bn_axis = 3
    else:
        bn_axis = 1
    x = Model_1(x,0.15,name='Model_1_1')
    x = Model_1(x,0.15,name='Model_1_2')
    x = Model_1(x,0.15,name='Model_1_3')
    x = Model_1(x,0.15,name='Model_1_4')
    #35 × 35 to 17 × 17 reduction module.
    x_red_11 = MaxPooling2D(3,strides=2,padding='valid',name='red_maxpool_1')(x)
    x_red_12 = conv2d(x,384,3,2,'valid',True,name='x_red1_c1')

    x_red_13 = conv2d(x,256,1,1,'same',True,name='x_red1_c2_1')
    x_red_13 = conv2d(x_red_13,256,3,1,'same',True,name='x_red1_c2_2')
    x_red_13 = conv2d(x_red_13,384,3,2,'valid',True,name='x_red1_c2_3')

    x = Concatenate(axis=3, name='red_concat_1')([x_red_11,x_red_12,x_red_13])

    x = Model_2(x,0.1,name='Model_2_1')
    x = Model_2(x,0.1,name='Model_2_2')
    x = Model_2(x,0.1,name='Model_2_3')
    x = Model_2(x,0.1,name='Model_2_4')
    x = Model_2(x,0.1,name='Model_2_5')
    x = Model_2(x,0.1,name='Model_2_6')
    x = Model_2(x,0.1,name='Model_2_7')

    #17 × 17 to 8 × 8 reduction module.
    x_red_21 = MaxPooling2D(3,strides=2,padding='valid',name='red_maxpool_2')(x)

    x_red_22 = conv2d(x,256,1,1,'same',True,name='x_red2_c11')
    x_red_22 = conv2d(x_red_22,384,3,2,'valid',True,name='x_red2_c12')

    x_red_23 = conv2d(x,256,1,1,'same',True,name='x_red2_c21')
    x_red_23 = conv2d(x_red_23,256,3,2,'valid',True,name='x_red2_c22')

    x_red_24 = conv2d(x,256,1,1,'same',True,name='x_red2_c31')
    x_red_24 = conv2d(x_red_24,256,3,1,'same',True,name='x_red2_c32')
    x_red_24 = conv2d(x_red_24,256,3,2,'valid',True,name='x_red2_c33')

    x = Concatenate(axis=3, name='red_concat_2')([x_red_21,x_red_22,x_red_23,x_red_24])

    x = Model_3(x,0.2,name='Model_3_1')
    x = Model_3(x,0.2,name='Model_3_2')
    x = Model_3(x,0.2,name='Model_3_3')

    x = GlobalAveragePooling2D(data_format='channels_last')(x)
    x = Dropout(0.6)(x)
    x = Dense(80, activation='softmax')(x)                 #Enter number of classes later on


